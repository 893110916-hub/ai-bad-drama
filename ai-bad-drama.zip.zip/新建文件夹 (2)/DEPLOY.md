# AI烂剧平台 - Vercel 手动部署指南

## 方法：通过 GitHub + Vercel 网站部署

### 第一步：创建 GitHub 仓库

1. 访问 https://github.com/new
2. 仓库名称：`ai-bad-drama`
3. 选择 **Public**（公开）
4. 点击 **Create repository**

### 第二步：上传代码到 GitHub

在项目文件夹中打开终端，执行：

```bash
cd C:\Users\ROG\.openclaw\workspace\ai-bad-drama

# 初始化 git
git init

# 添加所有文件
git add .

# 提交
git commit -m "Initial commit"

# 添加远程仓库（替换 YOUR_USERNAME 为你的GitHub用户名）
git remote add origin https://github.com/YOUR_USERNAME/ai-bad-drama.git

# 推送代码
git push -u origin main
```

### 第三步：在 Vercel 部署

1. 访问 https://vercel.com/new
2. 点击 **Import Git Repository**
3. 选择你的 `ai-bad-drama` 仓库
4. 点击 **Import**

### 第四步：配置环境变量

在 Vercel 部署页面，展开 **Environment Variables**，添加：

```
MONGODB_URI=mongodb+srv://948981697zax_db_user:calHHf0Kczgehqhr@cluster0.s9qhf31.mongodb.net/ai-bad-drama?retryWrites=true&w=majority
CLOUDINARY_CLOUD_NAME=dmcp0ohli
CLOUDINARY_API_KEY=496983793336765
CLOUDINARY_API_SECRET=xjcRwCHzg9-HZwendehiBXZQBMc
ADMIN_PASSWORD=your_admin_password_123
```

### 第五步：部署

点击 **Deploy** 按钮，等待部署完成！

---

## 部署后

- 网站地址：`https://ai-bad-drama.vercel.app`（或类似）
- 每次推送代码到 GitHub，Vercel 会自动重新部署

## 注意事项

1. **MongoDB IP白名单**：确保在 MongoDB Atlas 添加了 `0.0.0.0/0`
2. **免费额度**：Vercel 免费版每月 100GB 带宽
3. **自定义域名**：可以在 Vercel 设置中添加自己的域名
