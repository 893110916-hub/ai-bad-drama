import mongoose from 'mongoose';

const VideoSchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: { type: String, default: '' },
  creator: { type: String, required: true },
  category: { 
    type: String, 
    required: true,
    enum: ['剧情烂', '画风崩', '配音尬', '逻辑乱', '全方位烂']
  },
  badnessScore: { type: Number, required: true, min: 1, max: 10 },
  videoUrl: { type: String, required: true },
  thumbnailUrl: { type: String, default: '' },
  status: { 
    type: String, 
    required: true, 
    enum: ['pending', 'approved', 'rejected'],
    default: 'pending'
  },
  views: { type: Number, default: 0 },
  likes: { type: Number, default: 0 },
  likedBy: [{ type: String }], // IP addresses or session IDs
  fileSize: { type: Number, default: 0 },
  duration: { type: String, default: '00:00' },
}, {
  timestamps: true
});

export default mongoose.models.Video || mongoose.model('Video', VideoSchema);
