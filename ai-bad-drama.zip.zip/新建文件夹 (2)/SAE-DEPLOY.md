# AI烂剧平台 - 阿里云SAE部署指南

## 部署步骤

### 1. 打包代码
```bash
cd ai-bad-drama
npm install
npm run build
zip -r deploy.zip . -x "node_modules/*" ".git/*"
```

### 2. 创建SAE应用
- 访问 https://sae.console.aliyun.com/
- 创建应用，选择"Web应用"
- 技术栈：Node.js 18
- 部署方式：代码包部署

### 3. 配置环境变量
在SAE控制台，添加以下环境变量：

```
MONGODB_URI=mongodb+srv://948981697zax_db_user:calHHf0Kczgehqhr@cluster0.s9qhf31.mongodb.net/ai-bad-drama?retryWrites=true&w=majority
CLOUDINARY_CLOUD_NAME=dmcp0ohli
CLOUDINARY_API_KEY=496983793336765
CLOUDINARY_API_SECRET=xjcRwCHzg9-HZwendehiBXZQBMc
ADMIN_PASSWORD=19970314Zax
```

### 4. 配置启动命令
```
npm start
```

### 5. 访问配置
- 实例规格：0.5核 1GB（最低配，约50元/月）
- 访问方式：公网访问
- 自动分配域名

## 费用预估
- 免费额度：每月前100万次调用免费
- 超出后：约0.0001元/次调用
- 预计月费：50-100元（取决于访问量）

## 注意事项
1. 确保MongoDB Atlas已添加阿里云IP白名单
2. Cloudinary免费额度25GB/月
3. 建议开启自动扩缩容
