'use client';

import { useState, useEffect } from 'react';

interface Video {
  _id: string;
  title: string;
  description: string;
  creator: string;
  category: string;
  badnessScore: number;
  views: number;
  likes: number;
  status: string;
  videoUrl: string;
  createdAt: string;
}

export default function AdminPanel() {
  const [videos, setVideos] = useState<Video[]>([]);
  const [password, setPassword] = useState('');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<'pending' | 'approved' | 'rejected'>('pending');

  const fetchVideos = async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/admin?status=${activeTab}`, {
        headers: {
          'Authorization': `Bearer ${password}`
        }
      });
      
      if (res.ok) {
        const data = await res.json();
        setVideos(data.videos);
        setIsAuthenticated(true);
      } else {
        alert('密码错误');
      }
    } catch (error) {
      console.error('Fetch error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    fetchVideos();
  };

  const handleAction = async (id: string, action: 'approve' | 'reject') => {
    try {
      const res = await fetch('/api/admin', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${password}`
        },
        body: JSON.stringify({ id, action }),
      });

      if (res.ok) {
        setVideos(videos.filter(v => v._id !== id));
      }
    } catch (error) {
      console.error('Action failed:', error);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('确定删除这个视频吗？')) return;
    
    try {
      const res = await fetch(`/api/admin?id=${id}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${password}`
        }
      });

      if (res.ok) {
        setVideos(videos.filter(v => v._id !== id));
      }
    } catch (error) {
      console.error('Delete failed:', error);
    }
  };

  useEffect(() => {
    if (isAuthenticated) {
      fetchVideos();
    }
  }, [activeTab]);

  if (!isAuthenticated) {
    return (
      <div className="admin-login">
        <h2>🔐 管理员登录</h2>
        <form onSubmit={handleLogin}>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="输入管理员密码"
            required
          />
          <button type="submit">登录</button>
        </form>
      </div>
    );
  }

  return (
    <div className="admin-panel">
      <div className="admin-tabs">
        <button 
          className={activeTab === 'pending' ? 'active' : ''}
          onClick={() => setActiveTab('pending')}
        >
          待审核 ({videos.length})
        </button>
        <button 
          className={activeTab === 'approved' ? 'active' : ''}
          onClick={() => setActiveTab('approved')}
        >
          已通过
        </button>
        <button 
          className={activeTab === 'rejected' ? 'active' : ''}
          onClick={() => setActiveTab('rejected')}
        >
          已拒绝
        </button>
      </div>

      {loading ? (
        <p>加载中...</p>
      ) : videos.length === 0 ? (
        <p>暂无{activeTab === 'pending' ? '待审核' : activeTab === 'approved' ? '已通过' : '已拒绝'}的视频</p>
      ) : (
        <div className="admin-list">
          {videos.map((video) => (
            <div key={video._id} className="admin-item">
              <div className="admin-video-info">
                <h4>{video.title}</h4>
                <p>创作者: {video.creator} | 分类: {video.category} | 烂度: {video.badnessScore}/10</p>
                <p>{video.description}</p>
                <a href={video.videoUrl} target="_blank" rel="noopener noreferrer">
                  查看视频
                </a>
              </div>
              <div className="admin-actions">
                {activeTab === 'pending' && (
                  <>
                    <button 
                      className="approve-btn"
                      onClick={() => handleAction(video._id, 'approve')}
                    >
                      ✅ 通过
                    </button>
                    <button 
                      className="reject-btn"
                      onClick={() => handleAction(video._id, 'reject')}
                    >
                      ❌ 拒绝
                    </button>
                  </>
                )}
                <button 
                  className="delete-btn"
                  onClick={() => handleDelete(video._id)}
                >
                  🗑️ 删除
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
