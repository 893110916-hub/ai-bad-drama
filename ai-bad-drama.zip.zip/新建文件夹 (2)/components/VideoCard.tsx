'use client';

import { useState } from 'react';
import Link from 'next/link';

interface VideoCardProps {
  video: {
    _id: string;
    title: string;
    description: string;
    creator: string;
    category: string;
    badnessScore: number;
    views: number;
    likes: number;
    videoUrl: string;
    createdAt: string;
  };
}

export default function VideoCard({ video }: VideoCardProps) {
  const [likes, setLikes] = useState(video.likes);
  const [liked, setLiked] = useState(false);

  const handleLike = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    const action = liked ? 'unlike' : 'like';
    const ip = 'anonymous'; // 实际应该用真实IP
    
    try {
      const res = await fetch('/api/videos/' + video._id, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action, ip }),
      });
      
      if (res.ok) {
        const data = await res.json();
        setLikes(data.likes);
        setLiked(data.liked);
      }
    } catch (error) {
      console.error('Like failed:', error);
    }
  };

  const formatNumber = (num: number) => {
    if (num >= 10000) return (num / 10000).toFixed(1) + 'w';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'k';
    return num;
  };

  const formatTime = (timeStr: string) => {
    const date = new Date(timeStr);
    return `${date.getMonth() + 1}月${date.getDate()}日`;
  };

  return (
    <Link href={`/video/${video._id}`} className="video-card">
      <div className="video-thumb">
        <span className="badge">{video.category}</span>
        <span className="score-badge">烂度 {video.badnessScore}</span>
        <div className="play-icon">▶</div>
      </div>
      <div className="video-info">
        <div className="video-title">{video.title}</div>
        <div className="video-desc">{video.description || '暂无简介'}</div>
        <div className="video-meta">
          <div className="author">
            <div className="avatar"></div>
            <span>{video.creator}</span>
          </div>
          <div className="actions">
            <span 
              className={`action ${liked ? 'liked' : ''}`}
              onClick={handleLike}
            >
              {liked ? '❤️' : '🤍'} {formatNumber(likes)}
            </span>
            <span>▶ {formatNumber(video.views)}</span>
          </div>
        </div>
      </div>
    </Link>
  );
}
