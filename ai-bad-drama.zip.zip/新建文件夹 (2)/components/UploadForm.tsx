'use client';

import { useState, useCallback } from 'react';
import { useRouter } from 'next/navigation';

export default function UploadForm() {
  const router = useRouter();
  const [file, setFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    creator: '',
    category: '剧情烂',
    badnessScore: 5,
  });

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const selectedFile = e.target.files[0];
      if (selectedFile.size > 500 * 1024 * 1024) {
        alert('文件大小不能超过500MB');
        return;
      }
      setFile(selectedFile);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!file) {
      alert('请选择视频文件');
      return;
    }

    if (!formData.title || !formData.creator) {
      alert('请填写剧名和创作者');
      return;
    }

    setUploading(true);

    const data = new FormData();
    data.append('video', file);
    data.append('title', formData.title);
    data.append('description', formData.description);
    data.append('creator', formData.creator);
    data.append('category', formData.category);
    data.append('badnessScore', formData.badnessScore.toString());

    try {
      const res = await fetch('/api/upload', {
        method: 'POST',
        body: data,
      });

      if (res.ok) {
        alert('上传成功！等待审核后公开显示');
        router.push('/');
      } else {
        alert('上传失败，请重试');
      }
    } catch (error) {
      alert('上传出错：' + error);
    } finally {
      setUploading(false);
    }
  };

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const droppedFile = e.dataTransfer.files[0];
      if (droppedFile.size > 500 * 1024 * 1024) {
        alert('文件大小不能超过500MB');
        return;
      }
      setFile(droppedFile);
    }
  }, []);

  return (
    <form onSubmit={handleSubmit} className="upload-form">
      <div 
        className={`upload-area ${file ? 'has-file' : ''}`}
        onDrop={handleDrop}
        onDragOver={(e) => e.preventDefault()}
      >
        <input
          type="file"
          accept="video/*"
          onChange={handleFileChange}
          id="video-input"
          style={{ display: 'none' }}
        />
        <label htmlFor="video-input" style={{ cursor: 'pointer' }}>
          {file ? (
            <>
              <div style={{ fontSize: '2em', marginBottom: '10px' }}>✅</div>
              <p style={{ color: '#4ade80' }}>{file.name}</p>
              <p style={{ color: '#666', fontSize: '0.85em' }}>
                {(file.size / 1024 / 1024).toFixed(2)} MB
              </p>
            </>
          ) : (
            <>
              <div style={{ fontSize: '2.5em', marginBottom: '10px' }}>📁</div>
              <p>点击或拖拽视频到此处</p>
              <p style={{ color: '#666', fontSize: '0.85em', marginTop: '10px' }}>
                MP4 / WebM / MOV · 最大500MB
              </p>
            </>
          )}
        </label>
      </div>

      <div className="form-group">
        <label>剧名 *</label>
        <input
          type="text"
          value={formData.title}
          onChange={(e) => setFormData({ ...formData, title: e.target.value })}
          placeholder="给你的烂剧起个吸引人的名字"
          required
        />
      </div>

      <div className="form-group">
        <label>简介</label>
        <textarea
          value={formData.description}
          onChange={(e) => setFormData({ ...formData, description: e.target.value })}
          placeholder="介绍一下这部烂剧的亮点（或槽点）..."
          rows={3}
        />
      </div>

      <div className="form-group">
        <label>创作者昵称 *</label>
        <input
          type="text"
          value={formData.creator}
          onChange={(e) => setFormData({ ...formData, creator: e.target.value })}
          placeholder="你的大名"
          required
        />
      </div>

      <div className="form-group">
        <label>烂剧类型</label>
        <select
          value={formData.category}
          onChange={(e) => setFormData({ ...formData, category: e.target.value })}
        >
          <option value="剧情烂">剧情烂 - 故事让人摸不着头脑</option>
          <option value="画风崩">画风崩 - 人物变形、场景诡异</option>
          <option value="配音尬">配音尬 - 声音出戏、对白尴尬</option>
          <option value="逻辑乱">逻辑乱 - 前后矛盾、毫无逻辑</option>
          <option value="全方位烂">全方位烂 - 烂得全面、烂得彻底</option>
        </select>
      </div>

      <div className="form-group">
        <label>
          烂度评分: <span style={{ color: '#ff6b6b', fontSize: '1.2em' }}>{formData.badnessScore}</span>/10
        </label>
        <input
          type="range"
          min="1"
          max="10"
          value={formData.badnessScore}
          onChange={(e) => setFormData({ ...formData, badnessScore: parseInt(e.target.value) })}
          style={{ width: '100%', marginTop: '10px' }}
        />
      </div>

      <button type="submit" className="submit-btn" disabled={uploading}>
        {uploading ? '📤 上传中...' : '🚀 发布烂剧'}
      </button>
    </form>
  );
}
