# AI烂剧平台 - Vercel完整项目

## 快速开始

### 1. 克隆或下载项目
项目位置：`C:\Users\ROG\.openclaw\workspace\ai-bad-drama\`

### 2. 安装依赖
```bash
cd ai-bad-drama
npm install
```

### 3. 配置环境变量
创建 `.env.local` 文件：
```
MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/ai-bad-drama
CLOUDINARY_CLOUD_NAME=your_cloud_name
CLOUDINARY_API_KEY=your_api_key
CLOUDINARY_API_SECRET=your_api_secret
ADMIN_PASSWORD=your_admin_password
```

### 4. 本地运行
```bash
npm run dev
```
访问 http://localhost:3000

### 5. 部署到Vercel
```bash
npm i -g vercel
vercel
```

---

## 项目文件清单

### 配置文件
- `package.json` - 依赖配置
- `tsconfig.json` - TypeScript配置
- `next.config.js` - Next.js配置
- `next-env.d.ts` - 类型声明

### 核心代码
- `lib/db.ts` - MongoDB连接
- `lib/cloudinary.ts` - Cloudinary配置
- `models/Video.ts` - 视频数据模型

### API接口
- `app/api/videos/route.ts` - 获取视频列表
- `app/api/upload/route.ts` - 上传视频
- `app/api/admin/route.ts` - 审核接口

### 页面
- `app/page.tsx` - 首页（视频列表）
- `app/upload/page.tsx` - 上传页面
- `app/admin/page.tsx` - 审核后台

### 组件
- `components/VideoCard.tsx` - 视频卡片
- `components/UploadForm.tsx` - 上传表单
- `components/AdminPanel.tsx` - 审核面板

---

## 功能特性

### 已实现
✅ 视频上传（支持500MB）
✅ 视频列表展示
✅ 分类筛选（全部/最新/最热/最烂）
✅ 搜索功能
✅ 点赞系统
✅ 播放统计
✅ 审核机制（pending/approved/rejected）
✅ 管理员后台

### 待实现
- 视频播放页面
- 评论系统
- 用户系统（可选）
- 分享功能

---

## 免费额度说明

| 服务 | 免费额度 | 预计支持 |
|------|----------|----------|
| Vercel | 100GB/月 | ~1000人访问 |
| MongoDB Atlas | 512MB | ~500个视频 |
| Cloudinary | 25GB存储+25GB流量 | ~100个视频 |

**注意**: 视频文件较大，免费额度可能很快用完。建议：
1. 限制上传视频数量
2. 压缩视频质量
3. 或升级到付费方案

---

## 下一步

需要我：
1. 创建剩余的文件（页面组件、API接口）？
2. 生成部署脚本？
3. 写详细的数据库配置教程？
