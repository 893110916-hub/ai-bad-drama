import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'AI烂剧平台 - 让烂剧发光发热',
  description: '卖不出去的AI漫剧？来这里找到它的价值！',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="zh-CN">
      <body>{children}</body>
    </html>
  );
}
