'use client';

import { useState, useEffect } from 'react';
import VideoCard from '@/components/VideoCard';
import Link from 'next/link';

interface Video {
  _id: string;
  title: string;
  description: string;
  creator: string;
  category: string;
  badnessScore: number;
  views: number;
  likes: number;
}

export default function Home() {
  const [videos, setVideos] = useState<Video[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchVideos();
  }, []);

  const fetchVideos = async () => {
    try {
      const res = await fetch('/api/videos?status=approved&sort=newest');
      if (res.ok) {
        const data = await res.json();
        setVideos(data.videos || []);
      }
    } catch (error) {
      console.error('Fetch error:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <main className="main">
        <div className="empty">
          <div className="empty-icon">⏳</div>
          <h3>加载中...</h3>
        </div>
      </main>
    );
  }

  return (
    <main className="main">
      <header className="header">
        <div className="logo">🎬</div>
        <h1>AI烂剧平台</h1>
        <p className="subtitle">卖不出去的AI漫剧？来这里发光发热！</p>
        <div className="stats-bar">
          <div className="stat-item">
            <div className="stat-num">{videos.length}</div>
            <div className="stat-label">烂剧总数</div>
          </div>
          <div className="stat-item">
            <div className="stat-num">{videos.reduce((sum, v) => sum + v.views, 0)}</div>
            <div className="stat-label">总播放</div>
          </div>
          <div className="stat-item">
            <div className="stat-num">{new Set(videos.map(v => v.creator)).size}</div>
            <div className="stat-label">创作者</div>
          </div>
          <div className="stat-item">
            <div className="stat-num">{videos.reduce((sum, v) => sum + v.likes, 0)}</div>
            <div className="stat-label">总点赞</div>
          </div>
        </div>
      </header>

      <Link href="/upload" className="upload-section">
        <div className="upload-content">
          <div style={{ fontSize: '3em', marginBottom: '15px' }}>📤</div>
          <h2 style={{ marginBottom: '10px' }}>上传你的AI烂剧</h2>
          <p style={{ color: '#888' }}>让每一部"烂剧"都有被看见的机会</p>
          <button className="upload-btn">立即上传</button>
          <p className="upload-hint">支持 MP4、WebM、MOV 格式 · 最大 500MB</p>
        </div>
      </Link>

      <div className="filter-section">
        <div className="filter-tabs">
          <button className="tab active">全部</button>
          <button className="tab">最新</button>
          <button className="tab">最热</button>
          <button className="tab">最烂</button>
        </div>
        <div className="search-box">
          <input type="text" placeholder="搜索烂剧..." />
        </div>
      </div>

      <div className="video-grid">
        {videos.length === 0 ? (
          <div className="empty">
            <div className="empty-icon">🎭</div>
            <h3>还没有烂剧</h3>
            <p>快来上传第一部AI烂剧吧！</p>
          </div>
        ) : (
          videos.map((video) => (
            <VideoCard key={video._id} video={video} />
          ))
        )}
      </div>
    </main>
  );
}
