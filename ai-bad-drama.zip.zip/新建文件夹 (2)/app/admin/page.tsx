import AdminPanel from '@/components/AdminPanel';
import Link from 'next/link';

export default function AdminPage() {
  return (
    <main className="main">
      <div className="container">
        <div className="page-header">
          <Link href="/" className="back-link">← 返回首页</Link>
          <h1>🔐 审核后台</h1>
          <p>管理所有上传的视频内容</p>
        </div>
        
        <div className="admin-card">
          <AdminPanel />
        </div>
      </div>
    </main>
  );
}
