import UploadForm from '@/components/UploadForm';
import Link from 'next/link';

export default function UploadPage() {
  return (
    <main className="main">
      <div className="container">
        <div className="page-header">
          <Link href="/" className="back-link">← 返回首页</Link>
          <h1>🎬 发布AI烂剧</h1>
          <p>分享你的"杰作"，让更多人欣赏</p>
        </div>
        
        <div className="upload-card">
          <UploadForm />
        </div>
      </div>
    </main>
  );
}
