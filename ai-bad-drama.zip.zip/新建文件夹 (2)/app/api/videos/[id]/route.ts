import { NextRequest, NextResponse } from 'next/server';
import dbConnect from '@/lib/db';
import Video from '@/models/Video';

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    await dbConnect();

    const body = await request.json();
    const { action, ip } = body;
    const { id } = params;

    if (!id || !['like', 'unlike', 'view'].includes(action)) {
      return NextResponse.json({ success: false, error: 'Invalid request' }, { status: 400 });
    }

    const video = await Video.findById(id);
    if (!video) {
      return NextResponse.json({ success: false, error: 'Video not found' }, { status: 404 });
    }

    if (action === 'view') {
      video.views += 1;
      await video.save();
      return NextResponse.json({ success: true, views: video.views });
    }

    if (action === 'like') {
      if (!video.likedBy.includes(ip || 'anonymous')) {
        video.likes += 1;
        video.likedBy.push(ip || 'anonymous');
        await video.save();
      }
      return NextResponse.json({ success: true, likes: video.likes, liked: true });
    }

    if (action === 'unlike') {
      const targetIp = ip || 'anonymous';
      if (video.likedBy.includes(targetIp)) {
        video.likes -= 1;
        video.likedBy = video.likedBy.filter((i: string) => i !== targetIp);
        await video.save();
      }
      return NextResponse.json({ success: true, likes: video.likes, liked: false });
    }

    return NextResponse.json({ success: false, error: 'Invalid action' }, { status: 400 });

  } catch (error) {
    console.error('Update error:', error);
    return NextResponse.json({ success: false, error: 'Failed to update' }, { status: 500 });
  }
}
