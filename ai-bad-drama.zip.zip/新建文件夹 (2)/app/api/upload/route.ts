import { NextRequest, NextResponse } from 'next/server';
import dbConnect from '@/lib/db';
import Video from '@/models/Video';
import { v2 as cloudinary } from 'cloudinary';
import { writeFile } from 'fs/promises';
import { join } from 'path';
import { tmpdir } from 'os';

// 配置 Cloudinary
cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
});

export async function POST(request: NextRequest) {
  try {
    await dbConnect();

    const formData = await request.formData();
    
    const videoFile = formData.get('video') as File;
    const title = formData.get('title') as string;
    const description = formData.get('description') as string;
    const creator = formData.get('creator') as string;
    const category = formData.get('category') as string;
    const badnessScore = parseInt(formData.get('badnessScore') as string) || 5;

    if (!videoFile) {
      return NextResponse.json({ success: false, error: 'No video file' }, { status: 400 });
    }

    // 检查文件大小 (500MB)
    if (videoFile.size > 500 * 1024 * 1024) {
      return NextResponse.json({ success: false, error: 'File too large (max 500MB)' }, { status: 400 });
    }

    // 保存到临时文件
    const bytes = await videoFile.arrayBuffer();
    const buffer = Buffer.from(bytes);
    const tempFilePath = join(tmpdir(), `upload-${Date.now()}-${videoFile.name}`);
    await writeFile(tempFilePath, buffer);

    // 上传到 Cloudinary
    const uploadResult = await new Promise((resolve, reject) => {
      cloudinary.uploader.upload(tempFilePath, {
        resource_type: 'video',
        folder: 'ai-bad-drama',
        allowed_formats: ['mp4', 'mov', 'webm', 'avi'],
      }, (error, result) => {
        if (error) reject(error);
        else resolve(result);
      });
    });

    const result = uploadResult as any;

    // 创建视频记录
    const video = await Video.create({
      title: title || 'Untitled',
      description: description || '',
      creator: creator || 'Anonymous',
      category: category || '全方位烂',
      badnessScore,
      videoUrl: result.secure_url,
      thumbnailUrl: result.thumbnail_url || '',
      status: 'pending',
      fileSize: Math.round(result.bytes / 1024 / 1024 * 100) / 100,
      duration: result.duration ? formatDuration(result.duration) : '00:00',
    });

    return NextResponse.json({
      success: true,
      video,
      message: '上传成功，等待审核'
    }, { status: 201 });

  } catch (error) {
    console.error('Upload error:', error);
    return NextResponse.json({ success: false, error: 'Upload failed' }, { status: 500 });
  }
}

function formatDuration(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
}
